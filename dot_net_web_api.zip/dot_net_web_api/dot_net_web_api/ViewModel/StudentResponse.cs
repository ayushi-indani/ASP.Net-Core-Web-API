﻿namespace dot_net_web_api.ViewModel
{
    public class StudentResponse
    {
        public int student_key { get; set; }
        public string student_code { get; set; }
        public string student_name { get; set; }
    }
}
