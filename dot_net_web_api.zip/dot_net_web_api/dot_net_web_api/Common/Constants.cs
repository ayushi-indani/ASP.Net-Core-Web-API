﻿namespace dot_net_web_api.Common
{
    public class Constants
    {

    }
}
